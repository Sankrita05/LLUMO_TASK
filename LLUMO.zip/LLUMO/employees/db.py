# employees/db.py
from pymongo import MongoClient, ASCENDING
from django.conf import settings

client = MongoClient(settings.MONGO_URI)
db = client[settings.MONGO_DB_NAME]
employees_col = db["employees"]

# Ensure a unique index on employee_id
try:
    employees_col.create_index([("employee_id", ASCENDING)], unique=True)
except Exception:
    # index already exists or other issue — safe to ignore here
    pass
