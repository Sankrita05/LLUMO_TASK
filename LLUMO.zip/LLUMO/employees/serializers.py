# employees/serializers.py
from rest_framework import serializers
from datetime import datetime

class EmployeeSerializer(serializers.Serializer):
    employee_id = serializers.CharField(max_length=100)
    name = serializers.CharField()
    department = serializers.CharField()
    salary = serializers.IntegerField()
    joining_date = serializers.DateField(
        format="%Y-%m-%d", input_formats=["%Y-%m-%d"]
    )
    skills = serializers.ListField(child=serializers.CharField(), allow_empty=True)

    def to_representation(self, instance):
        # Convert MongoDB doc into API response
        joining_date = instance.get("joining_date")
        if isinstance(joining_date, datetime):
            joining_date = joining_date.strftime("%Y-%m-%d")
        return {
            "employee_id": instance.get("employee_id"),
            "name": instance.get("name"),
            "department": instance.get("department"),
            "salary": instance.get("salary"),
            "joining_date": joining_date,
            "skills": instance.get("skills", []),
        }
