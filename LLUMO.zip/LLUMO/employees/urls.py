from django.urls import path
from .views import (
    EmployeeListCreateView,
    EmployeeDetailView,
    AvgSalaryView,
    SearchBySkillView,
)

urlpatterns = [
    path("employees/", EmployeeListCreateView.as_view(), name="employees-list-create"),
    path("employees/<str:employee_id>/", EmployeeDetailView.as_view(), name="employee-detail"),
    path("employees/avg-salary/", AvgSalaryView.as_view(), name="avg-salary"),
    path("employees/search/", SearchBySkillView.as_view(), name="search-skill"),
]
