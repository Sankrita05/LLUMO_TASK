# employees/views.py
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status, permissions
from .db import employees_col
from .serializers import EmployeeSerializer
from pymongo.errors import DuplicateKeyError
from datetime import datetime, date

# Parse string -> datetime
def parse_date(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%d")

# Ensure we always store datetime.datetime (not datetime.date)
def ensure_datetime(val):
    if isinstance(val, str):
        return parse_date(val)
    elif isinstance(val, date) and not isinstance(val, datetime):
        return datetime.combine(val, datetime.min.time())
    return val

class EmployeeListCreateView(APIView):
    def get_permissions(self):
        # GET = public; POST = authenticated
        if self.request.method == "GET":
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

    def get(self, request):
        department = request.query_params.get("department")
        page = int(request.query_params.get("page", 1))
        page_size = int(request.query_params.get("page_size", 20))
        skip = (page - 1) * page_size

        query = {}
        if department:
            query["department"] = department

        cursor = (
            employees_col.find(query)
            .sort("joining_date", -1)
            .skip(skip)
            .limit(page_size)
        )
        docs = list(cursor)
        serializer = EmployeeSerializer(docs, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = EmployeeSerializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        data = serializer.validated_data
        jd = ensure_datetime(data["joining_date"])

        doc = {
            "employee_id": data["employee_id"],
            "name": data["name"],
            "department": data["department"],
            "salary": data["salary"],
            "joining_date": jd,
            "skills": data["skills"],
        }

        try:
            employees_col.insert_one(doc)
            return Response(EmployeeSerializer(doc).data, status=status.HTTP_201_CREATED)
        except DuplicateKeyError:
            return Response(
                {"detail": "employee_id already exists"},
                status=status.HTTP_400_BAD_REQUEST,
            )

class EmployeeDetailView(APIView):
    def get_permissions(self):
        if self.request.method == "GET":
            return [permissions.AllowAny()]
        return [permissions.IsAuthenticated()]

    def get_object(self, employee_id):
        return employees_col.find_one({"employee_id": employee_id})

    def get(self, request, employee_id):
        doc = self.get_object(employee_id)
        if not doc:
            return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)
        return Response(EmployeeSerializer(doc).data)

    def put(self, request, employee_id):
        data = request.data
        if not data:
            return Response({"detail": "No data provided."}, status=status.HTTP_400_BAD_REQUEST)

        update_fields = {}
        allowed = ["name", "department", "salary", "joining_date", "skills"]
        for field in allowed:
            if field in data:
                if field == "joining_date":
                    update_fields["joining_date"] = ensure_datetime(data["joining_date"])
                else:
                    update_fields[field] = data[field]

        if not update_fields:
            return Response({"detail": "No valid fields to update."}, status=status.HTTP_400_BAD_REQUEST)

        result = employees_col.update_one({"employee_id": employee_id}, {"$set": update_fields})
        if result.matched_count == 0:
            return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)

        doc = employees_col.find_one({"employee_id": employee_id})
        return Response(EmployeeSerializer(doc).data)

    def delete(self, request, employee_id):
        result = employees_col.delete_one({"employee_id": employee_id})
        if result.deleted_count == 0:
            return Response({"detail": "Not found."}, status=status.HTTP_404_NOT_FOUND)
        return Response({"detail": "Deleted"}, status=status.HTTP_200_OK)

class AvgSalaryView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        pipeline = [
            {"$group": {"_id": "$department", "avg_salary": {"$avg": "$salary"}}},
            {
                "$project": {
                    "_id": 0,
                    "department": "$_id",
                    "avg_salary": {"$round": ["$avg_salary", 0]},
                }
            },
        ]
        res = list(employees_col.aggregate(pipeline))
        return Response(res)

class SearchBySkillView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        skill = request.query_params.get("skill")
        if not skill:
            return Response(
                {"detail": "Provide ?skill=SkillName"},
                status=status.HTTP_400_BAD_REQUEST,
            )
        cursor = employees_col.find({"skills": {"$in": [skill]}})
        docs = list(cursor)
        return Response(EmployeeSerializer(docs, many=True).data)
